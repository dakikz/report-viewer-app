# Please follow each of the steps below to install and run the project on your local environment:

1. Go to this website https://nodejs.org/en/ and download the stable version (Recommended For Most Users) and install it on your machine
2. Once installed, unzip the folder named report-viewer-app-v2.zip
3. Open the project folder using your preferred IDE (preferrably VS Code)
4. In the CLI, navigate to the root folder of the project
5. Run 'npm i' to install all dependencied for the project
6. Run 'npm start' to start the dev server and run the project on your browser (normally it runs on http://localhost:3000)
