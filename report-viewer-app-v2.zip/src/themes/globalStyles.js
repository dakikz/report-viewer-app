import { createGlobalStyle } from "styled-components";

const GlobalStyle = createGlobalStyle`
    *{
        padding:0;
        margin: 0;
        box-sizing: border-box;
        font-family: 'Roboto', sans-serif;
    }

    :root{
        // Brand colors
        --accentGradient: linear-gradient(90deg, rgba(118,182,255,1) 0%, rgba(37,124,241,1) 100%);
        --buttonBlue: #4597f3;
        --buttonBlueHover: #76B6FF;

        --lightNavbar: #ffffff;
        --white: #ffffff;
        --whiteText: #ffffff;
        --blackText: #111111;

        --red: tomato;
        --sidenavWidth: 300px;
        --darkNavbar: #2c2c2c;
        
        --darkBody: #1c1c1c;

        --navbarLinksLight: #6e6e6e;
        --navbarLinksLightHover: #fafafa;
        --navbarLinksDark: #fafafa;
        --navbarLinksDarkHover: #6e6e6e;
    }
`;

export default GlobalStyle;
