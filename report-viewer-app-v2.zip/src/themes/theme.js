export const lightTheme = {
  body: "#f1f1f1",
  text: "var(--blackText)",
  navbar: "var(--lightNavbar)",
  buttonBlue: "var(--buttonBlue)",
  buttonBlueHover: "var(--buttonBlueHover)",
  buttonColorReversed: "var(--accentGradientReversed)",
  buttonTextColor: "var(--white)",
  blackText: "var(--blackText)",
  navbarLinks: "var(--navbarLinksLight)",
  navbarLinksHover: "var(--navbarLinksLightHover)",
};
export const darkTheme = {
  body: "var(--darkBody)",
  text: "var(--whiteText)",
  navbar: "var(--darkNavbar)",
  buttonBlue: "var(--buttonBlue)",
  buttonBlueHover: "var(--buttonBlueHover)",
  buttonColorReversed: "var(--accentGradientReversed)",
  buttonTextColor: "var(--white)",
  blackText: "var(--blackText)",
  navbarLinks: "var(--navbarLinksDark)",
  navbarLinksHover: "var(--navbarLinksDarkHover)",
};
