import React, { useState } from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import ReportList from "./components/ReportList";
import SpecificReportList from "./components/SpecificReportList";
import SpecificReportDetails from "./components/SpecificReportDetails";
import styled, { ThemeProvider } from "styled-components";
import Layout from "./components/Layouts/Layout";
import { darkTheme, lightTheme } from "./themes/theme";
import GlobalStyle from "./themes/globalStyles";

const StyledApp = styled.div`
  background-color: ${(props) => props.theme.body};
  color: ${(props) => props.theme.text};
  min-height: 100vh;
`;

const App = () => {
  const [theme, setTheme] = useState("light");
  const isDarkTheme = theme === "dark";

  const toggleTheme = () => {
    setTheme(isDarkTheme ? "light" : "dark");
  };

  return (
    <ThemeProvider theme={isDarkTheme ? darkTheme : lightTheme}>
      <GlobalStyle />
      <StyledApp>
        <Router>
          <Layout toggleTheme={toggleTheme} isDarkTheme={isDarkTheme}>
            <Routes>
              <Route path="/" element={<ReportList />} />
              <Route
                path="/reports/:specifiedId"
                element={<SpecificReportList />}
              />
              <Route
                path="/reports/:reportId/:billingPeriod"
                element={<SpecificReportDetails />}
              />
            </Routes>
          </Layout>
        </Router>
      </StyledApp>
    </ThemeProvider>
  );
};

export default App;
