import { useState } from "react";

const useSortableData = (items, initialSortBy) => {
  // Passing as a prop the initial sorting (in this case we are sorting by the "name" item, from ReportList.js component)
  const [sortBy, setSortBy] = useState(initialSortBy);
  const [sortOrder, setSortOrder] = useState("asc");

  const handleSortClick = (property) => {
    setSortOrder((prevOrder) =>
      sortBy === property ? (prevOrder === "asc" ? "desc" : "asc") : "asc"
    );
    setSortBy(property);
  };

  // Sorting functionality using .sort JS function
  const sortedItems = items.sort((a, b) => {
    const order = sortOrder === "asc" ? 1 : -1;
    const propA =
      typeof a[sortBy] === "string" ? a[sortBy].toLowerCase() : a[sortBy];
    const propB =
      typeof b[sortBy] === "string" ? b[sortBy].toLowerCase() : b[sortBy];

    if (propA < propB) {
      return -1 * order;
    }
    if (propA > propB) {
      return 1 * order;
    }
    return 0;
  });

  return { sortedItems, sortBy, sortOrder, handleSortClick };
};

export default useSortableData;
