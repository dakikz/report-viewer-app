import React, { useState, useEffect } from "react";
import axios from "axios";
import styled from "styled-components";
import ButtonLink from "./ButtonLink";
import ScreenTitle from "./ScreenTitle";
import { BiPhone } from "react-icons/bi";
import { CgData } from "react-icons/cg";
import useSortableData from "../utils/useSortableData";

const ReportsContainer = styled.div`
  display: flex;
  flex-direction: column;
  width: 100%;
`;

const ReportBox = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  border: 1px solid #ddd;
  padding: 16px;
  width: 100%;
  background-color: var(--white);
  margin-bottom: 10px;
  border-radius: 8px;
  color: var(--blackText);
`;
const ReportInfo = styled.div`
  display: flex;
`;
const CategoryIcon = styled.div`
  width: 50px;
  height: 50px;
  margin-right: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: #d7d7d7;
  color: #525252;
  border-radius: 100%;
`;

const SortButtonsOuter = styled.div`
  width: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-bottom: 15px;
`;
const SortButton = styled.button`
  width: 50%;
  border-color: var(--buttonBlue);
  background-color: var(--buttonBlue);
  color: var(--white);
  padding: 4px;
  cursor: pointer;
  transition: all 0.3s ease;

  &:hover {
    background-color: transparent;
    color: var(--buttonBlue);
  }

  &:nth-child(1) {
    border-radius: 100px 0 0 100px;
  }
  &:nth-child(2) {
    border-radius: 0 100px 100px 0;
  }
`;

const ReportList = () => {
  const [reports, setReports] = useState([]);
  const [error, setError] = useState(null);
  const { sortedItems, sortBy, sortOrder, handleSortClick } = useSortableData(
    reports,
    "name"
  );

  // Fetching the data from reports.json content array of objects and storing them inside 'reports' state
  useEffect(() => {
    const fetchReports = async () => {
      try {
        const response = await axios.get("/api/reports.json");
        setReports(response.data.content);
      } catch (error) {
        setError("Error fetching reports. Please try again.");
        console.error("Error fetching reports:", error);
      }
    };

    fetchReports();
  }, []);

  if (error) {
    return (
      <div>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div>
      <ScreenTitle>Available Reports</ScreenTitle>
      <SortButtonsOuter>
        {/* Using the useSortableData.js function  */}
        <SortButton onClick={() => handleSortClick("name")}>
          Sort by Name {sortBy === "name" && (sortOrder === "asc" ? "▼" : "▲")}
        </SortButton>
        <SortButton onClick={() => handleSortClick("description")}>
          Sort by Description{" "}
          {sortBy === "description" && (sortOrder === "asc" ? "▼" : "▲")}
        </SortButton>
      </SortButtonsOuter>
      <ReportsContainer>
        {sortedItems.map((report) => (
          <ReportBox key={report.id}>
            <ReportInfo>
              <CategoryIcon>
                {report.name === "Landline Accounts" ? (
                  <BiPhone size={35} />
                ) : (
                  ""
                )}
                {report.name === "Mobile Data Devices" ? (
                  <CgData size={35} />
                ) : (
                  ""
                )}
              </CategoryIcon>
              <div>
                <h3>{report.name}</h3>
                <p>{report.description}</p>
              </div>
            </ReportInfo>
            {/* Generating a button navigating to the relevant reports list, depending on the category (id) - for example /reports/41 */}
            <ButtonLink to={`/reports/${report.id}`}>View Reports</ButtonLink>
          </ReportBox>
        ))}
      </ReportsContainer>
    </div>
  );
};

export default ReportList;
