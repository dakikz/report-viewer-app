import React from "react";
import styled from "styled-components";

const OuterBodyImage = styled.div`
  height: 70px;
  width: 100%;
  background: var(--accentGradient);
`;

const BodyImage = () => {
  return <OuterBodyImage></OuterBodyImage>;
};

export default BodyImage;
