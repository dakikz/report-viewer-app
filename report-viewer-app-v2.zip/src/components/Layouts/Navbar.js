import React from "react";
import { FaMoon, FaRegSun, FaUserTie } from "react-icons/fa";
import { Link } from "react-router-dom";
import styled from "styled-components";

const NavOuter = styled.nav`
  height: 100vh;
  position: fixed;
  top: 0;
  left: 0;
  width: var(--sidenavWidth);
  padding: 25px;
  transition: all 0.3s ease;
`;
const NavInner = styled.div`
  background-color: ${(props) => props.theme.navbar};
  height: 100%;
  width: 100%;
  border-radius: 28px;
  box-shadow: 30px 0px 30px 0px rgba(0, 0, 0, 0.45);
  -webkit-box-shadow: 3px 0px 3px 0px rgba(0, 0, 0, 0.45);
  -moz-box-shadow: 3px 0px 3px 0px rgba(0, 0, 0, 0.45);
  display: flex;
  justify-content: flex-start;
  align-items: center;
  gap: 20px;
  flex-direction: column;
  padding-top: 80px;
  position: relative;
  overflow: hidden;

  &:after {
    content: "";
    position: absolute;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 100%;
    background: var(--accentGradient);
    height: 25px;
  }
`;
const UserDetails = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  margin-bottom: 30px;

  & h3 {
    margin: 20px auto 5px;
    font-size: 20px;
  }
`;
const ProfilePicture = styled.div`
  background: #ffffff;
  width: 80px;
  height: 80px;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 100%;
  overflow: hidden;
  border: 4px solid var(--buttonBlue);

  & svg {
    margin-top: 10px;
    color: var(--buttonBlue);
  }
`;
const DashboardLinks = styled.div`
  width: 90%;
  display: flex;
  gap: 10px;
  flex-direction: column;

  & .customLink {
    border: 2px solid ${(props) => props.theme.navbarLinks};
    border-radius: 100px;
    padding: 10px;
    text-decoration: none;
    color: ${(props) => props.theme.navbarLinks};
    text-align: center;

    &:hover {
      background-color: ${(props) => props.theme.navbarLinks};
      color: ${(props) => props.theme.navbarLinksHover};
      transition: all 0.3s ease;
    }
  }
`;

const TogglerOuter = styled.div`
  border: 1px solid var(--buttonBlue);
  background: var(--accentGradient);
  width: 50px;
  height: 28px;
  border-radius: 100px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: relative;
  bottom: 0;
  cursor: pointer;
  padding: 0 5px;

  &.darkMode {
    background: var(--darkBody);
    border: 1px solid var(--darkBody);
  }
`;
const ToggleCircle = styled.div`
  background-color: #ffffff;
  width: 20px;
  height: 20px;
  border-radius: 100%;
  position: absolute;
  left: 3px;
  transition: all 0.3s ease;

  &.darkMode {
    left: calc(100% - 23px);
  }
`;

const linksArray = [
  { name: "Home", link: "/" },
  { name: "Landline Reports", link: "/reports/41" },
  { name: "Mob. Data Reports", link: "/reports/245" },
];

const Navbar = ({ toggleTheme, isDarkTheme }) => {
  const togglee = () => {
    toggleTheme();
  };

  return (
    <NavOuter>
      <NavInner>
        <UserDetails>
          <ProfilePicture>
            <FaUserTie size={65} />
          </ProfilePicture>
          <h3>John Doe</h3>
          <p>Account Manager</p>
        </UserDetails>
        <DashboardLinks>
          {linksArray.map((item, idx) => (
            <Link to={item.link} className="customLink" key={idx}>
              {item.name}
            </Link>
          ))}
        </DashboardLinks>
        <TogglerOuter
          onClick={togglee}
          className={isDarkTheme ? "darkMode" : "lightMode"}
        >
          <FaMoon size={15} color={"#ffd700"} />
          <FaRegSun size={15} color={"#ffd700"} />

          <ToggleCircle className={isDarkTheme ? "darkMode" : "lightMode"} />
        </TogglerOuter>
      </NavInner>
    </NavOuter>
  );
};

export default Navbar;
