import React from "react";
import styled from "styled-components";

const FooterOuter = styled.footer`
  bottom: 0;
  width: 100%;
  text-align: right;
  padding: 10px;
  position: fixed;
  bottom: 0;
  color: #cccccc;
`;

const Footer = () => {
  const d = new Date();
  let year = d.getFullYear();

  return <FooterOuter>All rights reserved © {year}</FooterOuter>;
};

export default Footer;
