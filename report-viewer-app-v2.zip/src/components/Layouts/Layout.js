import React from "react";
import Navbar from "./Navbar";
import Footer from "./Footer";
import styled from "styled-components";
import BodyImage from "./BodyImage";

const Main = styled.main`
  margin-left: var(--sidenavWidth);
  padding: 30px 40px;
`;

const Layout = ({ children, toggleTheme, isDarkTheme }) => {
  return (
    <>
      <Navbar toggleTheme={toggleTheme} isDarkTheme={isDarkTheme} />
      <BodyImage />
      <Main>{children}</Main>
      <Footer />
    </>
  );
};

export default Layout;
