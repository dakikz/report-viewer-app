import React from "react";
import { Link } from "react-router-dom";
import styled from "styled-components";

const ButtonLinkStyle = styled(Link)`
  background: ${(props) => props.theme.buttonBlue};
  border-radius: 100px;
  padding: 10px;
  display: flex;
  justify-content: center;
  align-items: center;
  max-width: 200px;
  width: 100%;
  color: ${(props) => props.theme.buttonTextColor};
  text-decoration: none;
  transition: all 0.3s ease;

  &:hover {
    background: ${(props) => props.theme.buttonBlueHover};
  }

  &.backTo {
    background-color: tomato;
  }
`;

const ButtonLink = ({ to, children, backButton }) => {
  return (
    <ButtonLinkStyle to={to} className={backButton && "backTo"}>
      {children}
    </ButtonLinkStyle>
  );
};

export default ButtonLink;
