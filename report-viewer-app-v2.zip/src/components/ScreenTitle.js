import React from "react";
import styled from "styled-components";

const H2Title = styled.h2`
  font-size: 28px;
  position: relative;
  padding-bottom: 8px;
  margin-bottom: 20px;
  display: inline-block;

  &:after {
    content: "";
    width: 30%;
    height: 5px;
    background: var(--accentGradient);
    position: absolute;
    bottom: 0;
    left: 0;
    border-radius: 100px;
  }
`;

const ScreenTitle = ({ children }) => {
  return <H2Title>{children}</H2Title>;
};

export default ScreenTitle;
