import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import ButtonLink from "./ButtonLink";
import ScreenTitle from "./ScreenTitle";
import styled from "styled-components";
import moment from "moment/moment";

const DateSelectContainer = styled.div`
  display: flex;
  justify-content: center;
  gap: 20px;
  border-radius: 100px;

  & select {
    width: 70px;
    border: none;
    border-radius: 100px;
    text-align: center;
  }
`;
const ReportContainer = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 20px;
  margin-top: 40px;
  margin-bottom: 40px;
`;
const ReportBox = styled.div`
  padding: 25px 30px;
  box-shadow: 4px 3px 2px -1px rgba(0, 0, 0, 0.15);
  -webkit-box-shadow: 4px 3px 2px -1px rgba(0, 0, 0, 0.15);
  -moz-box-shadow: 4px 3px 2px -1px rgba(0, 0, 0, 0.15);
  background-color: var(--white);
  color: var(--blackText);
  border-radius: 8px;
  max-width: 250px;
  width: 100%;

  & p {
    margin-bottom: 3px;
    display: flex;
    justify-content: space-between;
  }

  & div {
    margin-bottom: 20px;
  }
`;
const SpecificReportList = () => {
  const [reports, setReports] = useState([]);
  const [loading, setLoading] = useState(true);
  // eslint-disable-next-line no-unused-vars
  const [error, setError] = useState(null);
  const { specifiedId } = useParams();
  const [selectedMonth, setSelectedMonth] = useState("");
  const [selectedYear, setSelectedYear] = useState("");
  const [allMonths, setAllMonths] = useState([]);
  const [allYears, setAllYears] = useState([]);

  // useEffect's purpose below:
  // fetching reports based on a specified ID
  // formatting data
  // handling errors
  useEffect(() => {
    const fetchReports = async () => {
      try {
        const response = await axios.get(`/api/reports`);
        const allReports = response.data;

        // If it's an array, it filters out reports that start with the specified ID
        if (Array.isArray(allReports)) {
          const relevantReports = allReports.filter((report) =>
            report.startsWith(`${specifiedId}-`)
          );

          // Extracting the reportId and billingPeriod from the filename, formats them, creates a new object and storing them in reports useState. Ex: {id: '41, period: '201708'}
          const formattedReports = relevantReports.map((report) => {
            const [reportId, billingPeriod] = report
              .replace(".json", "")
              .split("-");
            const formattedBillingPeriod = formatBillingPeriod(billingPeriod);

            return {
              id: reportId,
              period: formattedBillingPeriod,
            };
          });

          setReports(formattedReports);

          // Extracting unique months and years from billing periods and stores them in allMonths and allYears state
          const uniqueMonths = Array.from(
            new Set(formattedReports.map((report) => report.period.slice(4)))
          );
          const uniqueYears = Array.from(
            new Set(formattedReports.map((report) => report.period.slice(0, 4)))
          );

          // Updating states
          setAllMonths(uniqueMonths);
          setAllYears(uniqueYears);
        } else {
          // If the response is not an array, it sets an error message in the state.
          setError("Invalid response from the server. response_not_array");
          console.error("Invalid response from the server:", response);
        }
      } catch (error) {
        //  If the response encounters an error during the API call, it sets an error message in the state.
        setError("Error fetching reports. Please try again. api_call_error");
        console.error("Error fetching reports:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchReports();
  }, [specifiedId]);

  // Separate years from months and combines them in this format example: 201708
  const formatBillingPeriod = (billingPeriod) => {
    const year = billingPeriod.slice(0, 4);
    const month = billingPeriod.slice(4, 6);
    return `${year}${month}`;
  };

  const handleMonthChange = (e) => {
    setSelectedMonth(e.target.value);
  };

  const handleYearChange = (e) => {
    setSelectedYear(e.target.value);
  };

  return (
    <div>
      <ScreenTitle>
        Reports with ID: <i>{specifiedId}</i>
      </ScreenTitle>
      <DateSelectContainer>
        <div>
          <label htmlFor="month">Month: </label>
          <select id="month" onChange={handleMonthChange} value={selectedMonth}>
            <option value="">All</option>
            {allMonths.map((month) => (
              <option key={month} value={month}>
                {month}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="year">Year: </label>
          <select id="year" onChange={handleYearChange} value={selectedYear}>
            <option value="">All</option>
            {allYears.map((year) => (
              <option key={year} value={year}>
                {year}
              </option>
            ))}
          </select>
        </div>
      </DateSelectContainer>
      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          {/* Filtering and displaying reports that only match the month and/or year 
        selected from the dropdowns, if selected, otherwise it displays them all  */}
          {reports.length > 0 ? (
            <ReportContainer>
              {reports
                .filter(
                  (report) =>
                    (!selectedMonth ||
                      report.period.slice(4) === selectedMonth) &&
                    (!selectedYear ||
                      report.period.slice(0, 4) === selectedYear)
                )
                .map((report, idx) => (
                  <ReportBox key={idx}>
                    <div>
                      <p>
                        <strong>Report ID:</strong> {report.id}
                      </p>
                      <p>
                        <strong>Billing Period:</strong>{" "}
                        {/* Using moment.js to format dates easily */}
                        {moment(report.period).format("MMM YYYY")}
                      </p>
                    </div>
                    {/* Generating a button navigating to the relevant report, depending on the report ID and report period - for example /reports/41/201708 */}
                    <ButtonLink to={`/reports/${report.id}/${report.period}`}>
                      View Report
                    </ButtonLink>
                  </ReportBox>
                ))}
            </ReportContainer>
          ) : (
            <p>No reports available for {specifiedId}.</p>
          )}
          <ButtonLink to="/" backButton>
            Back to Reports
          </ButtonLink>
        </>
      )}
    </div>
  );
};

export default SpecificReportList;
