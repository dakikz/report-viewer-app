import React, { useState, useEffect } from "react";
import axios from "axios";
import { useParams, useNavigate } from "react-router-dom";
import styled from "styled-components";
import ScreenTitle from "./ScreenTitle";
import {
  BiSolidChevronLeftSquare,
  BiSolidChevronRightSquare,
  BiX,
} from "react-icons/bi";

const SearchBox = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
  position: relative;
  max-width: 250px;
`;
const SearchInput = styled.input`
  border-radius: 100px;
  padding: 4px 25px 4px 15px;
  width: 100%;
  border: none;
  outline: 2px solid #cccccc;

  &:focus {
    outline: 2px solid var(--buttonBlue);
  }
`;
const ClearSearch = styled.button`
  position: absolute;
  right: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  background-color: transparent;
  border: none;
  cursor: pointer;
`;
const SearchAndClose = styled.div`
  display: flex;
  justify-content: space-between;
  margin-bottom: 20px;
`;
const BackButton = styled.button`
  border: none;
  outline: none;
  cursor: pointer;
  color: var(--white);
  border: 2px solid var(--red);
  background-color: var(--red);
  padding: 2px 12px;
  border-radius: 100px;
`;

const TableOuter = styled.div`
  border: 1px solid #cccccc;
`;
const TableRow = styled.div`
  display: flex;
  flex-wrap: wrap;
  padding: 4px 0;

  &:nth-of-type(odd) {
    background-color: #e3e3e3;
    color: ${(props) => props.theme.blackText};
  }
  &:nth-child(1) {
    background-color: #9ec8ff;
    padding: 0;

    & > div:not(:nth-child(1)) {
      border-left: 1px solid #e2efff;
    }
  }
`;

const TableCell = styled.div`
  display: flex;
  flex: 1;
  width: 100%;
  padding: 0 8px;
`;

const PaginationButton = styled.button`
  border: none;
  outline: none;
  cursor: pointer;
  background-color: transparent;
  color: ${(props) => props.theme.text};
`;

const TableHeaderCell = styled.div`
  display: flex;
  flex: 1;
  width: 100%;
  cursor: pointer;
  padding: 20px 8px;
`;

const Pagination = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 30px;
  margin-top: 10px;
`;

const SortIndicator = styled.span`
  margin-left: 4px;
`;
const NoResultsMessage = styled.p`
  color: #9ec8ff;
  padding: 14px 8px;
`;

// Set the wording to be more readable on the table headers
const columnDisplayNames = {
  accountId: "Account ID",
  officeLocation: "Office Location",
  chargesEuro: "Charges in euro (€)",
  devicePhysicalAddress: "Device Physical Address",
  usageBytes: "Data Usage (in Bytes / KB / MB / GB / TB)",
};

// Formatting Bytes to something more meaningful
const formatBytes = (bytes) => {
  if (typeof bytes !== "number") {
    return bytes;
  }
  const sizes = ["Bytes", "KB", "MB", "GB", "TB"];
  if (bytes === 0) return "0 Byte";
  const i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
  return Math.round((bytes / Math.pow(1024, i)) * 100) / 100 + " " + sizes[i];
};

const SpecificReportDetails = () => {
  const [reportData, setReportData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [sortOrder, setSortOrder] = useState("asc");
  const [sortColumn, setSortColumn] = useState("accountId");
  const { reportId, billingPeriod } = useParams(); // Using useParams to access the parameters of the current route
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const itemsPerPage = 15;
  const navigate = useNavigate();

  useEffect(() => {
    const fetchReportDetails = async () => {
      try {
        // Fetching the relevant information for reportId and billingPeriod
        // according to the selected URL parameters
        // Example: useParams will get this from the route -> reports/41/201708
        // and return this -> 41-201708.json for the API call
        const response = await axios.get(
          `/api/reports/${reportId}-${billingPeriod}.json`
        );
        const reportDetails = response.data;

        setReportData(reportDetails);
        // Reset to the first page when it fetches new data
        setCurrentPage(1);
      } catch (error) {
        setError("Error fetching report details. Please try again.");
        console.error("Error fetching report details:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchReportDetails();
  }, [reportId, billingPeriod, searchTerm]);

  const handleBackClick = () => {
    navigate(-1);
  };

  const handleSortClick = (column) => {
    setSortOrder((prevOrder) =>
      column !== sortColumn ? "asc" : prevOrder === "asc" ? "desc" : "asc"
    );
    setSortColumn(column);
  };

  // Checks if data is an array and if it is,
  // it creates a copy of the array
  // then it sorts the data bases on the specified column and order
  const sortedData = Array.isArray(reportData.data)
    ? [...reportData.data].sort((a, b) => {
        const order = sortOrder === "asc" ? 1 : -1;
        const columnIndex = reportData.columns.indexOf(sortColumn);

        const isNumeric = (value) =>
          !isNaN(parseFloat(value)) && isFinite(value);

        const getValue = (item) => {
          const value = columnIndex !== -1 ? item[columnIndex] : null;
          if (value === null) {
            return "";
          }

          return isNumeric(value) ? parseFloat(value) : value.toString();
        };

        const aValue = getValue(a);
        const bValue = getValue(b);

        // Use localeCompare for string comparison
        if (typeof aValue === "string" && typeof bValue === "string") {
          return order * aValue.localeCompare(bValue);
        }

        // Use numeric comparison for numbers
        return order * (aValue - bValue);
      })
    : [];

  const filteredData = sortedData.filter((item) =>
    // Checks if the search term exists on any column and returns an array containing these terms
    item.some((column, columnIndex) =>
      typeof column === "number" &&
      reportData.columns[columnIndex].toLowerCase().includes("bytes")
        ? formatBytes(column).toLowerCase().includes(searchTerm.toLowerCase())
        : typeof column === "string" &&
          column.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);
  const lastIndex = currentPage * itemsPerPage;
  const firstIndex = lastIndex - itemsPerPage;
  const currentItems = filteredData.slice(firstIndex, lastIndex);

  const nextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage((prevPage) => prevPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prevPage) => prevPage - 1);
    }
  };

  return (
    <div>
      <ScreenTitle>Report Details</ScreenTitle>
      <SearchAndClose>
        <SearchBox>
          <SearchInput
            type="text"
            placeholder="Search..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          {searchTerm && (
            <ClearSearch onClick={() => setSearchTerm("")}>
              <BiX size={24} />
            </ClearSearch>
          )}
        </SearchBox>
        <BackButton onClick={handleBackClick}>Close Report </BackButton>
      </SearchAndClose>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <>
          {error ? (
            <p>{error}</p>
          ) : (
            <>
              <TableOuter>
                <TableRow>
                  {reportData &&
                    reportData.columns &&
                    reportData.columns.map((column, idx) => (
                      <TableHeaderCell
                        key={idx}
                        onClick={() => handleSortClick(column)}
                      >
                        <strong>{columnDisplayNames[column] || column}</strong>
                        {sortColumn === column && (
                          <SortIndicator>
                            {sortOrder === "asc" ? "▼" : "▲"}
                          </SortIndicator>
                        )}
                      </TableHeaderCell>
                    ))}
                </TableRow>
                {filteredData.length === 0 ? (
                  <NoResultsMessage>
                    Search criteria do not match any data.
                  </NoResultsMessage>
                ) : (
                  currentItems.map((dataz, idxx) => (
                    <TableRow key={idxx}>
                      {dataz.map((column, idxxx) => (
                        <TableCell key={idxxx}>
                          {column !== ""
                            ? formatBytes(column !== undefined ? column : 0)
                            : "-"}
                        </TableCell>
                      ))}
                    </TableRow>
                  ))
                )}
              </TableOuter>
              <Pagination>
                <PaginationButton onClick={prevPage}>
                  {" "}
                  <BiSolidChevronLeftSquare size={35} />
                </PaginationButton>
                <div>
                  Page {currentPage} of {totalPages}
                </div>
                <PaginationButton onClick={nextPage}>
                  <BiSolidChevronRightSquare size={35} />
                </PaginationButton>
              </Pagination>
            </>
          )}
        </>
      )}
    </div>
  );
};

export default SpecificReportDetails;
